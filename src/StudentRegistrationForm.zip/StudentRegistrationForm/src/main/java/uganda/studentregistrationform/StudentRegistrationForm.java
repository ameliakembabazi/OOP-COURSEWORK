

package uganda.studentregistrationform;

/**
 *
 * @author anita
 */
//public class StudentRegistrationForm {

   // public static void main(String[] args) {
      //  System.out.println("Hello World!");
        
        
        
        
        import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.regex.*;

public class StudentRegistrationForm extends JFrame {

    private JTextField txtFirst, txtLast, txtEmail, txtConfirmEmail;
    private JPasswordField txtPass, txtConfirmPass;
    private JComboBox<Integer> cbYear, cbDay;
    private JComboBox<String> cbMonth, cbDept;
    private JRadioButton rbMale, rbFemale;
    private JTextArea txtOutput;
    private JLabel lblError;

    private final String FILE = "students.csv";

    public StudentRegistrationForm() {
        setTitle("New Student Registration Form");
        setSize(850, 520);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel main = new JPanel(new BorderLayout());
        add(main);

        // ---------- LEFT FORM ----------
        JPanel form = new JPanel(new GridBagLayout());
        main.add(form, BorderLayout.CENTER);

        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(5, 5, 5, 5);
        g.anchor = GridBagConstraints.WEST;

        int y = 0;

        txtFirst = addField("First Name:", form, g, y++);
        txtLast = addField("Last Name:", form, g, y++);
        txtEmail = addField("Email:", form, g, y++);
        txtConfirmEmail = addField("Confirm Email:", form, g, y++);

        txtPass = new JPasswordField(15);
        txtConfirmPass = new JPasswordField(15);
        addPassword("Password:", txtPass, form, g, y++);
        addPassword("Confirm Password:", txtConfirmPass, form, g, y++);

        // DOB
        g.gridx = 0; g.gridy = y;
        form.add(new JLabel("DOB:"), g);

        cbYear = new JComboBox<>();
        for (int i = 1960; i <= LocalDate.now().getYear(); i++) cbYear.addItem(i);

        cbMonth = new JComboBox<>(Month.values());
        cbDay = new JComboBox<>();

        cbYear.addActionListener(e -> updateDays());
        cbMonth.addActionListener(e -> updateDays());
        updateDays();

        JPanel dob = new JPanel();
        dob.add(cbYear); dob.add(cbMonth); dob.add(cbDay);

        g.gridx = 1;
        form.add(dob, g);
        y++;

        // Gender
        g.gridx = 0; g.gridy = y;
        form.add(new JLabel("Gender:"), g);

        rbMale = new JRadioButton("Male");
        rbFemale = new JRadioButton("Female");
        ButtonGroup bg = new ButtonGroup();
        bg.add(rbMale); bg.add(rbFemale);

        JPanel gp = new JPanel();
        gp.add(rbMale); gp.add(rbFemale);

        g.gridx = 1;
        form.add(gp, g);
        y++;

        // Department
        g.gridx = 0; g.gridy = y;
        form.add(new JLabel("Department:"), g);

        cbDept = new JComboBox<>(new String[]{
                "Select...",
                "Civil",
                "CSE",
                "Electrical",
                "E&C",
                "Mechanical"
        });

        g.gridx = 1;
        form.add(cbDept, g);
        y++;

        // Buttons
        JButton btnSubmit = new JButton("Submit");
        JButton btnCancel = new JButton("Cancel");

        JPanel bp = new JPanel();
        bp.add(btnSubmit); bp.add(btnCancel);

        g.gridx = 1; g.gridy = y;
        form.add(bp, g);

        // Error label
        lblError = new JLabel(" ");
        lblError.setForeground(Color.RED);
        g.gridy++;
        form.add(lblError, g);

        // ---------- RIGHT PANEL ----------
        JPanel right = new JPanel(new BorderLayout());
        right.setPreferredSize(new Dimension(350, 0));
        main.add(right, BorderLayout.EAST);

        right.add(new JLabel("Your Data is Below:"), BorderLayout.NORTH);

        txtOutput = new JTextArea();
        txtOutput.setEditable(false);
        right.add(new JScrollPane(txtOutput), BorderLayout.CENTER);

        // Actions
        btnSubmit.addActionListener(e -> handleSubmit());
        btnCancel.addActionListener(e -> clearForm());
    }

    // ---------- HELPERS ----------
    private JTextField addField(String label, JPanel p, GridBagConstraints g, int y) {
        g.gridx = 0; g.gridy = y;
        p.add(new JLabel(label), g);
        JTextField t = new JTextField(15);
        g.gridx = 1;
        p.add(t, g);
        return t;
    }

    private void addPassword(String label, JPasswordField f, JPanel p, GridBagConstraints g, int y) {
        g.gridx = 0; g.gridy = y;
        p.add(new JLabel(label), g);
        g.gridx = 1;
        p.add(f, g);
    }

    private void updateDays() {
        cbDay.removeAllItems();
        int year = (int) cbYear.getSelectedItem();
        Month m = (Month) cbMonth.getSelectedItem();
        int days = m.length(Year.isLeap(year));
        for (int i = 1; i <= days; i++) cbDay.addItem(i);
    }

    private void handleSubmit() {
        lblError.setText(" ");

        String first = txtFirst.getText().trim();
        String last = txtLast.getText().trim();
        String email = txtEmail.getText().trim();
        String cemail = txtConfirmEmail.getText().trim();
        String pass = new String(txtPass.getPassword());
        String cpass = new String(txtConfirmPass.getPassword());

        if (first.isEmpty() || last.isEmpty() || email.isEmpty() || pass.isEmpty()) {
            error("All fields are required");
            return;
        }

        if (!email.matches("^[\\w.-]+@[\\w.-]+\\.[a-z]{2,}$")) {
            error("Invalid email format");
            return;
        }

        if (!email.equals(cemail)) {
            error("Emails do not match");
            return;
        }

        if (!pass.matches("^(?=.*[A-Za-z])(?=.*\\d).{8,20}$")) {
            error("Password must be 8-20, include letter & digit");
            return;
        }

        if (!pass.equals(cpass)) {
            error("Passwords do not match");
            return;
        }

        if (!rbMale.isSelected() && !rbFemale.isSelected()) {
            error("Select gender");
            return;
        }

        if (cbDept.getSelectedIndex() == 0) {
            error("Select department");
            return;
        }

        int y = (int) cbYear.getSelectedItem();
        int m = cbMonth.getSelectedIndex() + 1;
        int d = (int) cbDay.getSelectedItem();

        LocalDate dob = LocalDate.of(y, m, d);
        int age = Period.between(dob, LocalDate.now()).getYears();

        if (age < 16 || age > 60) {
            error("Age must be 16–60");
            return;
        }

        String id = generateID();
        String gender = rbMale.isSelected() ? "M" : "F";
        String dept = cbDept.getSelectedItem().toString();
        String date = dob.toString();

        String record = id + " | " + first + " " + last +
                " | " + gender + " | " + dept +
                " | " + date + " | " + email;

        txtOutput.append(record + "\n");

        saveCSV(id, first, last, gender, dept, date, email);

        JOptionPane.showMessageDialog(this, "Student registered successfully!");
    }

    private void error(String msg) {
        lblError.setText(msg);
        JOptionPane.showMessageDialog(this, msg, "Validation Error", JOptionPane.ERROR_MESSAGE);
    }

    private void clearForm() {
        txtFirst.setText("");
        txtLast.setText("");
        txtEmail.setText("");
        txtConfirmEmail.setText("");
        txtPass.setText("");
        txtConfirmPass.setText("");
        rbMale.setSelected(false);
        rbFemale.setSelected(false);
        cbDept.setSelectedIndex(0);
    }

    private String generateID() {
        int year = LocalDate.now().getYear();
        int count = 1;

        try (BufferedReader br = new BufferedReader(new FileReader(FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith(String.valueOf(year))) count++;
            }
        } catch (Exception ignored) {}

        return year + "-" + String.format("%05d", count);
    }

    private void saveCSV(String... data) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(FILE, true))) {
            pw.println(String.join(",", data));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "File write error");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new StudentRegistrationForm().setVisible(true));
    }
}
    

